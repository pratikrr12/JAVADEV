package GUI;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Exceptions.AccNotFound;
import Exceptions.InvalidAmount;
import Exceptions.MaxBalance;
import Exceptions.MaxWithdraw;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class WithdrawAcc extends JFrame implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;


	/**
	 * Create the frame.
	 */
	public WithdrawAcc() {
		setTitle("Withdraw From Account");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDepositToAccount = new JLabel("Withdraw From Account");
		lblDepositToAccount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDepositToAccount.setHorizontalAlignment(SwingConstants.CENTER);
		lblDepositToAccount.setBounds(10, 11, 414, 36);
		contentPane.add(lblDepositToAccount);
		
		JLabel lblName = new JLabel("Account Number:");
		lblName.setHorizontalAlignment(SwingConstants.RIGHT);
		lblName.setBounds(0, 86, 106, 14);
		contentPane.add(lblName);
		
		textField = new JTextField();
		textField.setBounds(116, 83, 216, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(116, 147, 216, 20);
		contentPane.add(textField_1);
		
		JLabel lblAmount = new JLabel("Amount:");
		lblAmount.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAmount.setBounds(10, 150, 96, 14);
		contentPane.add(lblAmount);
		
		JButton btnDeposit = new JButton("Withdraw");
		btnDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				int aacountNum;
				int amt;
				aacountNum=Integer.parseInt(textField.getText());
				amt=Integer.parseInt(textField_1.getText());
					try {
						int a=JOptionPane.showConfirmDialog(getComponent(0), "Confirm?");
						if(a==0)
						{
							
							Connection connection;
	                        connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/banksystemdb", "root", "");

	                        if (amt <= 0) {
	                            throw new InvalidAmount("");
	                        }

	                        String sqlCheckAccountExistance = "SELECT COUNT(*) FROM Accounts WHERE accountNo = ?";
	                        String sqlCheckBalance = "SELECT Balance from Accounts where accountNo = ?";
	                        String sqlWithDrawLimit = "SELECT MaxWithdrawLimit from Accounts where accountNo = ?";
	                        String sqlWithDrawFromAcc = "Update Accounts Set Balance =  Balance - ? where AccountNo  = ?";

	                        /*Check account number exists or not*/
	                        PreparedStatement preparedStatement = connection.prepareStatement(sqlCheckAccountExistance);
	                        preparedStatement.setInt(1, aacountNum);

	                        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                            // Retrieving the result
	                            if (resultSet.next()) {
	                                int count = resultSet.getInt(1);

	                                if (count <= 0) {
	                                    throw new AccNotFound("");
	                                }
	                            }
	                        }
	                        
	                        /*Get the balance for an account no and throw error if insufficient balance*/
	                        preparedStatement = connection.prepareStatement(sqlCheckBalance);
	                        preparedStatement.setInt(1, aacountNum);
	                        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                            // Retrieving the result
	                            if (resultSet.next()) {
	                                int balance = resultSet.getInt(1);

	                                if (balance < amt) {
	                                    throw new MaxBalance("");
	                                }
	                            }
	                        }
	                        
	                        /*Get the MaxWithdrawLimit for an account no and throw error limit exceeds*/
	                        preparedStatement = connection.prepareStatement(sqlWithDrawLimit);
	                        preparedStatement.setInt(1, aacountNum);
	                        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                            // Retrieving the result
	                            if (resultSet.next()) {
	                                int maxWithdrawLimit = resultSet.getInt(1);

	                                if (maxWithdrawLimit < amt) {
	                                    throw new MaxWithdraw("");
	                                }
	                            }
	                        }

	                        /*Withdraw the amount*/
	                        preparedStatement = connection.prepareStatement(sqlWithDrawFromAcc);
	                        preparedStatement.setInt(1, amt);
	                        preparedStatement.setInt(2, aacountNum);
	                        preparedStatement.execute();
	                       
	                        textField.setText(null);
	                        textField_1.setText(null);
	                        
							JOptionPane.showMessageDialog(getComponent(0),"Withdraw Successful");
							dispose();
						}
						else
						{
						textField.setText(null);
						textField_1.setText(null);
						
						}
						
					} 
					catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					catch (MaxBalance e1) {
						JOptionPane.showMessageDialog(getComponent(0), "Insufficient Balance");
						JOptionPane.showMessageDialog(getComponent(0),"Failed");
						textField.setText(null);
						textField_1.setText(null);
				
					} catch (AccNotFound e1) {
						JOptionPane.showMessageDialog(getComponent(0), "Sorry! Account Not Found");
						JOptionPane.showMessageDialog(getComponent(0),"Failed");
						textField.setText(null);
						textField_1.setText(null);
					
					} catch (MaxWithdraw e1) {
						JOptionPane.showMessageDialog(getComponent(0), "Maximum Withdraw Limit Exceed");
						JOptionPane.showMessageDialog(getComponent(0),"Failed");
						textField.setText(null);
						textField_1.setText(null);
						
					} catch (InvalidAmount e1) {
						JOptionPane.showMessageDialog(getComponent(0), "Invalid Amount");
						JOptionPane.showMessageDialog(getComponent(0),"Failed");
						textField.setText(null);
						textField_1.setText(null);
					}
				
				
					textField.setText(null);
					textField_1.setText(null);
				
				
				

			}
		});
		btnDeposit.setBounds(73, 212, 89, 23);
		contentPane.add(btnDeposit);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(243, 212, 89, 23);
		contentPane.add(btnReset);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				textField.setText(null);
				textField_1.setText(null);
			}
		});
		
		
		
		
		
		
		
	}
}
