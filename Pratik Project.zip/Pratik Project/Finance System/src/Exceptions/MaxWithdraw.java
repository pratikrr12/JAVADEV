package Exceptions;

public class MaxWithdraw extends Exception {


	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MaxWithdraw(String s)
	{
		super(s);
	}

}
